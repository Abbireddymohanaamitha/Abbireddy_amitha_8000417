-- Stored procedures for Event Management Portal.
-- Use DELIMITER to define procedure bodies in MySQL.

USE `event_management_portal`;

DROP PROCEDURE IF EXISTS `GetUserEvents`;
DROP PROCEDURE IF EXISTS `GetEventSessions`;
DROP PROCEDURE IF EXISTS `GetFeedbackSummary`;
DROP PROCEDURE IF EXISTS `GetOrganizerEvents`;
DROP PROCEDURE IF EXISTS `GetEventResources`;

DELIMITER $$
CREATE PROCEDURE `GetUserEvents`(IN in_user_id INT)
BEGIN
  SELECT e.event_id,
         e.event_name,
         e.city,
         e.venue,
         e.start_date,
         e.end_date,
         e.status
  FROM Registrations r
  JOIN Events e ON e.event_id = r.event_id
  WHERE r.user_id = in_user_id
  ORDER BY e.start_date;
END$$

CREATE PROCEDURE `GetEventSessions`(IN in_event_id INT)
BEGIN
  SELECT s.session_id,
         s.session_title,
         CONCAT(u.first_name,' ',u.last_name) AS speaker_name,
         s.start_datetime,
         s.end_datetime,
         s.room,
         s.session_type
  FROM Sessions s
  JOIN Users u ON u.user_id = s.speaker_id
  WHERE s.event_id = in_event_id
  ORDER BY s.start_datetime;
END$$

CREATE PROCEDURE `GetFeedbackSummary`(IN in_event_id INT)
BEGIN
  SELECT e.event_id,
         e.event_name,
         COUNT(f.feedback_id) AS total_feedback,
         ROUND(AVG(f.rating),2) AS average_rating,
         SUM(CASE WHEN f.rating <= 2 THEN 1 ELSE 0 END) AS low_rating_count,
         SUM(CASE WHEN f.rating >= 4 THEN 1 ELSE 0 END) AS positive_rating_count
  FROM Events e
  LEFT JOIN Feedback f ON f.event_id = e.event_id
  WHERE e.event_id = in_event_id
  GROUP BY e.event_id, e.event_name;
END$$

CREATE PROCEDURE `GetOrganizerEvents`(IN in_organizer_id INT)
BEGIN
  SELECT e.event_id,
         e.event_name,
         e.city,
         e.start_date,
         e.end_date,
         e.status,
         COUNT(r.registration_id) AS registration_count,
         ROUND(AVG(f.rating),2) AS avg_rating
  FROM Events e
  LEFT JOIN Registrations r ON r.event_id = e.event_id
  LEFT JOIN Feedback f ON f.event_id = e.event_id
  WHERE e.organizer_id = in_organizer_id
  GROUP BY e.event_id, e.event_name, e.city, e.start_date, e.end_date, e.status
  ORDER BY e.start_date;
END$$

CREATE PROCEDURE `GetEventResources`(IN in_event_id INT)
BEGIN
  SELECT resource_id,
         resource_name,
         resource_type,
         url,
         uploaded_at
  FROM Resources
  WHERE event_id = in_event_id
  ORDER BY uploaded_at;
END$$
DELIMITER ;
