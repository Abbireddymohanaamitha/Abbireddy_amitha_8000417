-- View definitions for the Event Management Portal.

USE `event_management_portal`;

DROP VIEW IF EXISTS `vw_upcoming_events`;
DROP VIEW IF EXISTS `vw_event_feedback_summary`;
DROP VIEW IF EXISTS `vw_user_registration_summary`;
DROP VIEW IF EXISTS `vw_resource_summary`;
DROP VIEW IF EXISTS `vw_organizer_summary`;

CREATE VIEW `vw_upcoming_events` AS
SELECT e.event_id,
       e.event_name,
       e.city,
       e.venue,
       e.start_date,
       e.end_date,
       e.status,
       COUNT(r.registration_id) AS total_registrations
FROM Events e
LEFT JOIN Registrations r ON r.event_id = e.event_id
WHERE e.status = 'upcoming'
GROUP BY e.event_id, e.event_name, e.city, e.venue, e.start_date, e.end_date, e.status;

CREATE VIEW `vw_event_feedback_summary` AS
SELECT e.event_id,
       e.event_name,
       COUNT(f.feedback_id) AS feedback_count,
       ROUND(AVG(f.rating),2) AS average_rating,
       MIN(f.rating) AS min_rating,
       MAX(f.rating) AS max_rating
FROM Events e
LEFT JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.event_id, e.event_name;

CREATE VIEW `vw_user_registration_summary` AS
SELECT u.user_id,
       CONCAT(u.first_name,' ',u.last_name) AS user_name,
       u.email,
       u.city,
       u.user_type,
       COUNT(r.registration_id) AS total_registrations,
       COUNT(DISTINCT r.event_id) AS distinct_events
FROM Users u
LEFT JOIN Registrations r ON r.user_id = u.user_id
GROUP BY u.user_id, user_name, u.email, u.city, u.user_type;

CREATE VIEW `vw_resource_summary` AS
SELECT e.event_id,
       e.event_name,
       SUM(CASE WHEN r.resource_type = 'pdf' THEN 1 ELSE 0 END) AS pdf_count,
       SUM(CASE WHEN r.resource_type = 'image' THEN 1 ELSE 0 END) AS image_count,
       SUM(CASE WHEN r.resource_type = 'link' THEN 1 ELSE 0 END) AS link_count,
       SUM(CASE WHEN r.resource_type = 'video' THEN 1 ELSE 0 END) AS video_count,
       SUM(CASE WHEN r.resource_type = 'slide' THEN 1 ELSE 0 END) AS slide_count,
       COUNT(r.resource_id) AS total_resources
FROM Events e
LEFT JOIN Resources r ON r.event_id = e.event_id
GROUP BY e.event_id, e.event_name;

CREATE VIEW `vw_organizer_summary` AS
SELECT u.user_id AS organizer_id,
       CONCAT(u.first_name,' ',u.last_name) AS organizer_name,
       COUNT(DISTINCT e.event_id) AS total_events,
       SUM(CASE WHEN e.status = 'upcoming' THEN 1 ELSE 0 END) AS upcoming_events,
       SUM(CASE WHEN e.status = 'ongoing' THEN 1 ELSE 0 END) AS ongoing_events,
       SUM(CASE WHEN e.status = 'completed' THEN 1 ELSE 0 END) AS completed_events,
       SUM(CASE WHEN e.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_events
FROM Users u
LEFT JOIN Events e ON e.organizer_id = u.user_id
WHERE u.user_type = 'organizer'
GROUP BY u.user_id, organizer_name;
