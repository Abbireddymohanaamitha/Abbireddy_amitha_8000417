-- Trigger definitions for the Event Management Portal.

USE `event_management_portal`;

DROP TRIGGER IF EXISTS `trg_events_auto_complete`;
DROP TRIGGER IF EXISTS `trg_registrations_prevent_duplicates`;
DROP TRIGGER IF EXISTS `trg_feedback_rating_validate`;

DELIMITER $$
CREATE TRIGGER `trg_events_auto_complete`
BEFORE UPDATE ON `Events`
FOR EACH ROW
BEGIN
  IF NEW.end_date < CURDATE()
     AND NEW.status IN ('upcoming','ongoing') THEN
    SET NEW.status = 'completed';
  END IF;
END$$

CREATE TRIGGER `trg_registrations_prevent_duplicates`
BEFORE INSERT ON `Registrations`
FOR EACH ROW
BEGIN
  IF EXISTS (
    SELECT 1
    FROM `Registrations`
    WHERE user_id = NEW.user_id
      AND event_id = NEW.event_id
  ) THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Duplicate registration detected for the same user and event.';
  END IF;
END$$

CREATE TRIGGER `trg_feedback_rating_validate`
BEFORE INSERT ON `Feedback`
FOR EACH ROW
BEGIN
  IF NEW.rating < 1 OR NEW.rating > 5 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Feedback rating must be between 1 and 5.';
  END IF;
END$$

CREATE TRIGGER `trg_feedback_rating_validate_update`
BEFORE UPDATE ON `Feedback`
FOR EACH ROW
BEGIN
  IF NEW.rating < 1 OR NEW.rating > 5 THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Feedback rating must be between 1 and 5.';
  END IF;
END$$
DELIMITER ;
