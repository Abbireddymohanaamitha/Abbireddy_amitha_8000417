# Event Management Portal Database System

## Project Overview

This project implements a production-quality MySQL 8.0 database for an Event Management Portal. It includes database creation, full DDL, indexing, realistic sample data, SQL exercises, advanced queries, stored procedures, views, triggers, and reporting queries.

## Database Design

The database contains the following tables:
- `Users`: attendees, organizers, speakers, and administrators.
- `Events`: event metadata, organizer ownership, scheduling, and status.
- `Sessions`: individual agenda items within an event.
- `Registrations`: user enrollments for events.
- `Feedback`: event feedback submitted by registered users.
- `Resources`: event documents, slides, links, videos, and images.

## ER Diagram Description

The conceptual ER design includes:
- One `User` may organize many `Events`.
- One `Event` may include many `Sessions`.
- One `Event` may have many `Registrations` and many `Resources`.
- One `Registration` may correspond to one `Feedback` entry.
- One `User` may submit many `Feedback` entries and many `Registrations`.

## Table Relationships

- `Events.organizer_id` -> `Users.user_id`
- `Sessions.event_id` -> `Events.event_id`
- `Sessions.speaker_id` -> `Users.user_id`
- `Registrations.user_id` -> `Users.user_id`
- `Registrations.event_id` -> `Events.event_id`
- `Feedback.registration_id` -> `Registrations.registration_id`
- `Feedback.event_id` -> `Events.event_id`
- `Feedback.user_id` -> `Users.user_id`
- `Resources.event_id` -> `Events.event_id`

## Project Structure

```
EventManagementSQLProject/
├── database/
│   ├── 01_create_database.sql
│   ├── 02_create_tables.sql
│   ├── 03_constraints.sql
│   ├── 04_indexes.sql
│   ├── 05_insert_sample_data.sql
│
├── queries/
│   ├── exercise_queries.sql
│   ├── advanced_queries.sql
│
├── procedures/
│   ├── stored_procedures.sql
│
├── views/
│   ├── views.sql
│
├── triggers/
│   ├── triggers.sql
│
├── reports/
│   ├── reports.sql
│
└── README.md
```

## How to Run

### Step 1: Open MySQL Shell or Workbench
Connect to your MySQL 8.0 database instance.

### Step 2: Execute scripts in order
1. `database/01_create_database.sql`
2. `database/02_create_tables.sql`
3. `database/03_constraints.sql`
4. `database/04_indexes.sql`
5. `database/05_insert_sample_data.sql`
6. `views/views.sql`
7. `procedures/stored_procedures.sql`
8. `triggers/triggers.sql`

### Step 3: Run queries
- Use `queries/exercise_queries.sql` for practice exercises.
- Use `queries/advanced_queries.sql` for optimized solutions.
- Use `reports/reports.sql` for reporting summaries.

## MySQL Commands

```sql
SOURCE /path/to/EventManagementSQLProject/database/01_create_database.sql;
SOURCE /path/to/EventManagementSQLProject/database/02_create_tables.sql;
SOURCE /path/to/EventManagementSQLProject/database/03_constraints.sql;
SOURCE /path/to/EventManagementSQLProject/database/04_indexes.sql;
SOURCE /path/to/EventManagementSQLProject/database/05_insert_sample_data.sql;
SOURCE /path/to/EventManagementSQLProject/views/views.sql;
SOURCE /path/to/EventManagementSQLProject/procedures/stored_procedures.sql;
SOURCE /path/to/EventManagementSQLProject/triggers/triggers.sql;
```

## Query Descriptions

- `exercise_queries.sql`: Complete answers to 25 SQL exercises, including analytics and event management use cases.
- `advanced_queries.sql`: Basic and optimized versions using joins, CTEs, window functions, ranking, and anti-joins.
- `reports/reports.sql`: Standard business intelligence reports for registrations, feedback, organizers, and resources.

## Screenshots Section

> Add screenshots here after executing queries in MySQL Workbench or your preferred SQL client.

## Future Enhancements

- Add separate `Speakers` and `Organizers` tables with richer profiles.
- Add role-based access control and user authentication.
- Add automated scheduled jobs for status updates and reminders.
- Build a front-end dashboard using web technologies with REST API integration.
- Add event budgeting, sponsorship, and ticket sales modules.
