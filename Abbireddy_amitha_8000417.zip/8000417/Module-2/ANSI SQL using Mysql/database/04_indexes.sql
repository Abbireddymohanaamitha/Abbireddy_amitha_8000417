-- Index creation for performance tuning in the Event Management Portal.

USE `event_management_portal`;

CREATE INDEX `idx_users_email` ON `Users` (`email`);
CREATE INDEX `idx_users_city` ON `Users` (`city`);

CREATE INDEX `idx_events_city` ON `Events` (`city`);
CREATE INDEX `idx_events_status` ON `Events` (`status`);
CREATE INDEX `idx_events_start_date` ON `Events` (`start_date`);
CREATE INDEX `idx_events_end_date` ON `Events` (`end_date`);

CREATE INDEX `idx_registrations_date` ON `Registrations` (`registration_date`);
CREATE INDEX `idx_registrations_user_event` ON `Registrations` (`user_id`, `event_id`);

CREATE INDEX `idx_feedback_rating` ON `Feedback` (`rating`);
CREATE INDEX `idx_feedback_event` ON `Feedback` (`event_id`);
CREATE INDEX `idx_feedback_user` ON `Feedback` (`user_id`);

CREATE INDEX `idx_sessions_speaker` ON `Sessions` (`speaker_id`);
CREATE INDEX `idx_sessions_event` ON `Sessions` (`event_id`);
CREATE INDEX `idx_sessions_start_datetime` ON `Sessions` (`start_datetime`);
CREATE INDEX `idx_sessions_end_datetime` ON `Sessions` (`end_datetime`);

CREATE INDEX `idx_resources_type` ON `Resources` (`resource_type`);
CREATE INDEX `idx_resources_event` ON `Resources` (`event_id`);
