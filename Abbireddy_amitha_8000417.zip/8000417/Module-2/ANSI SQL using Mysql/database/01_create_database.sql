-- Event Management Portal Database Creation Script
-- Compatible with MySQL 8.0

DROP DATABASE IF EXISTS `event_management_portal`;
CREATE DATABASE `event_management_portal` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `event_management_portal`;

-- Schema:
-- Users, Events, Sessions, Registrations, Feedback, Resources

-- The database is now ready for table creation.
