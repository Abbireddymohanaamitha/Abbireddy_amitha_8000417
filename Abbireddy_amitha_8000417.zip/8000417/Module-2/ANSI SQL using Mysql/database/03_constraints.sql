-- Constraints and foreign keys for the Event Management Portal database.
-- This script adds required unique constraints, checks, and relational integrity.

USE `event_management_portal`;

ALTER TABLE `Users`
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD CONSTRAINT `chk_users_city_not_empty` CHECK (`city` <> ''),
  ADD CONSTRAINT `chk_users_name_not_empty` CHECK (`first_name` <> '' AND `last_name` <> '');

ALTER TABLE `Events`
  ADD CONSTRAINT `fk_events_organizer` FOREIGN KEY (`organizer_id`) REFERENCES `Users`(`user_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `chk_event_dates` CHECK (`end_date` >= `start_date`),
  ADD CONSTRAINT `chk_event_city_not_empty` CHECK (`city` <> ''),
  ADD CONSTRAINT `chk_event_venue_not_empty` CHECK (`venue` <> '');

ALTER TABLE `Sessions`
  ADD CONSTRAINT `fk_sessions_event` FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sessions_speaker` FOREIGN KEY (`speaker_id`) REFERENCES `Users`(`user_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  ADD CONSTRAINT `chk_session_times` CHECK (`end_datetime` > `start_datetime`),
  ADD CONSTRAINT `chk_session_room_not_empty` CHECK (`room` <> '');

ALTER TABLE `Registrations`
  ADD CONSTRAINT `fk_registrations_user` FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_registrations_event` FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `chk_registration_date` CHECK (`registration_date` >= '2000-01-01');

ALTER TABLE `Feedback`
  ADD CONSTRAINT `fk_feedback_registration` FOREIGN KEY (`registration_id`) REFERENCES `Registrations`(`registration_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_feedback_event` FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_feedback_user` FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `chk_feedback_rating` CHECK (`rating` BETWEEN 1 AND 5);

ALTER TABLE `Resources`
  ADD CONSTRAINT `fk_resources_event` FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `chk_resource_name` CHECK (`resource_name` <> '');
