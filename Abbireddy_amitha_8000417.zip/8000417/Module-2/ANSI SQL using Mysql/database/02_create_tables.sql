-- Table creation script for the Event Management Portal database.
-- This script defines the table structure with primary keys and basic columns.

USE `event_management_portal`;

DROP TABLE IF EXISTS `Feedback`;
DROP TABLE IF EXISTS `Registrations`;
DROP TABLE IF EXISTS `Sessions`;
DROP TABLE IF EXISTS `Resources`;
DROP TABLE IF EXISTS `Events`;
DROP TABLE IF EXISTS `Users`;

CREATE TABLE `Users` (
  `user_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(50) NOT NULL,
  `last_name` VARCHAR(50) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(25),
  `city` VARCHAR(80) NOT NULL,
  `user_type` ENUM('attendee','organizer','speaker','admin') NOT NULL DEFAULT 'attendee',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Events` (
  `event_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_name` VARCHAR(150) NOT NULL,
  `description` TEXT,
  `organizer_id` INT UNSIGNED NOT NULL,
  `city` VARCHAR(80) NOT NULL,
  `venue` VARCHAR(150) NOT NULL,
  `start_date` DATE NOT NULL,
  `end_date` DATE NOT NULL,
  `status` ENUM('upcoming','ongoing','completed','cancelled') NOT NULL DEFAULT 'upcoming',
  `capacity` INT UNSIGNED NOT NULL DEFAULT 100,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Sessions` (
  `session_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_id` INT UNSIGNED NOT NULL,
  `session_title` VARCHAR(180) NOT NULL,
  `speaker_id` INT UNSIGNED NOT NULL,
  `start_datetime` DATETIME NOT NULL,
  `end_datetime` DATETIME NOT NULL,
  `room` VARCHAR(80) NOT NULL,
  `capacity` INT UNSIGNED NOT NULL DEFAULT 50,
  `session_type` ENUM('workshop','talk','panel','networking') NOT NULL DEFAULT 'talk',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Registrations` (
  `registration_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `event_id` INT UNSIGNED NOT NULL,
  `registration_date` DATE NOT NULL,
  `status` ENUM('confirmed','cancelled','pending') NOT NULL DEFAULT 'confirmed',
  `ticket_type` ENUM('standard','vip','student') NOT NULL DEFAULT 'standard',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`registration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Feedback` (
  `feedback_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `registration_id` INT UNSIGNED NOT NULL,
  `event_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `rating` TINYINT UNSIGNED NOT NULL,
  `comments` TEXT,
  `submitted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `Resources` (
  `resource_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_id` INT UNSIGNED NOT NULL,
  `resource_name` VARCHAR(180) NOT NULL,
  `resource_type` ENUM('pdf','image','link','video','slide') NOT NULL DEFAULT 'pdf',
  `url` VARCHAR(500) NOT NULL,
  `uploaded_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
