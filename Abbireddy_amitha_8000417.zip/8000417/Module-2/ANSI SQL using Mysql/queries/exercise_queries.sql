-- Exercise Queries for the Event Management Portal Database
-- Each query solves one of the exercises listed in the project requirements.

USE `event_management_portal`;

-- Exercise 1: User Upcoming Events
-- List all upcoming events a user is registered for in their city, sorted by start date.
SELECT u.user_id,
       u.first_name,
       u.last_name,
       e.event_id,
       e.event_name,
       e.city,
       e.start_date,
       e.end_date,
       e.status
FROM Users u
JOIN Registrations r ON r.user_id = u.user_id
JOIN Events e ON e.event_id = r.event_id
WHERE u.user_id = 5
  AND e.status = 'upcoming'
  AND e.city = u.city
ORDER BY e.start_date ASC;

-- Exercise 2: Top Rated Events
-- Identify events with highest average rating, considering only those with at least 10 feedback submissions.
SELECT e.event_id,
       e.event_name,
       COUNT(f.feedback_id) AS feedback_count,
       ROUND(AVG(f.rating),2) AS avg_rating
FROM Events e
JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.event_id, e.event_name
HAVING feedback_count >= 10
ORDER BY avg_rating DESC, feedback_count DESC;

-- Exercise 3: Inactive Users
-- Retrieve users who have not registered for any events in the last 90 days.
SELECT u.user_id,
       u.first_name,
       u.last_name,
       u.email,
       u.city,
       MAX(r.registration_date) AS last_registration_date
FROM Users u
LEFT JOIN Registrations r ON r.user_id = u.user_id
GROUP BY u.user_id, u.first_name, u.last_name, u.email, u.city
HAVING MAX(r.registration_date) < DATE_SUB(CURDATE(), INTERVAL 90 DAY)
   OR MAX(r.registration_date) IS NULL;

-- Exercise 4: Peak Session Hours
-- Count sessions scheduled between 10 AM and 12 PM for each event.
SELECT e.event_id,
       e.event_name,
       COUNT(s.session_id) AS morning_session_count
FROM Events e
LEFT JOIN Sessions s ON s.event_id = e.event_id
  AND TIME(s.start_datetime) >= '10:00:00'
  AND TIME(s.start_datetime) < '12:00:00'
GROUP BY e.event_id, e.event_name
ORDER BY morning_session_count DESC;

-- Exercise 5: Most Active Cities
-- Top 5 cities with highest distinct registrations.
SELECT e.city,
       COUNT(DISTINCT r.user_id) AS distinct_attendees,
       COUNT(r.registration_id) AS total_registrations
FROM Registrations r
JOIN Events e ON e.event_id = r.event_id
GROUP BY e.city
ORDER BY distinct_attendees DESC, total_registrations DESC
LIMIT 5;

-- Exercise 6: Event Resource Summary
-- Number of PDFs, images, and links per event.
SELECT e.event_id,
       e.event_name,
       SUM(CASE WHEN resource_type = 'pdf' THEN 1 ELSE 0 END) AS pdf_count,
       SUM(CASE WHEN resource_type = 'image' THEN 1 ELSE 0 END) AS image_count,
       SUM(CASE WHEN resource_type = 'link' THEN 1 ELSE 0 END) AS link_count
FROM Events e
LEFT JOIN Resources r ON r.event_id = e.event_id
GROUP BY e.event_id, e.event_name;

-- Exercise 7: Low Feedback Alerts
-- Users who gave rating below 3 with comments and event names.
SELECT u.user_id,
       CONCAT(u.first_name,' ',u.last_name) AS user_name,
       e.event_name,
       f.rating,
       f.comments,
       f.submitted_at
FROM Feedback f
JOIN Users u ON u.user_id = f.user_id
JOIN Events e ON e.event_id = f.event_id
WHERE f.rating < 3
  AND f.comments IS NOT NULL
ORDER BY f.submitted_at DESC;

-- Exercise 8: Sessions per Upcoming Event
-- Display upcoming events with session count.
SELECT e.event_id,
       e.event_name,
       e.start_date,
       e.end_date,
       COUNT(s.session_id) AS session_count
FROM Events e
LEFT JOIN Sessions s ON s.event_id = e.event_id
WHERE e.status = 'upcoming'
GROUP BY e.event_id, e.event_name, e.start_date, e.end_date
ORDER BY session_count DESC;

-- Exercise 9: Organizer Event Summary
-- For each organizer show event count by status.
SELECT u.user_id AS organizer_id,
       CONCAT(u.first_name,' ',u.last_name) AS organizer_name,
       e.status,
       COUNT(e.event_id) AS event_count
FROM Events e
JOIN Users u ON u.user_id = e.organizer_id
GROUP BY u.user_id, organizer_name, e.status
ORDER BY organizer_name, event_count DESC;

-- Exercise 10: Feedback Gap
-- Events with registrations but no feedback.
SELECT e.event_id,
       e.event_name,
       COUNT(DISTINCT r.registration_id) AS registrations,
       COUNT(f.feedback_id) AS feedback_count
FROM Events e
JOIN Registrations r ON r.event_id = e.event_id
LEFT JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.event_id, e.event_name
HAVING registrations > 0
   AND feedback_count = 0;

-- Exercise 11: Daily New User Count
-- Users registered each day in the last 7 days.
SELECT DATE(created_at) AS registration_date,
       COUNT(user_id) AS new_users
FROM Users
WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
GROUP BY registration_date
ORDER BY registration_date DESC;

-- Exercise 12: Event with Maximum Sessions
-- Find event(s) with the highest session count.
WITH session_counts AS (
  SELECT event_id,
         COUNT(session_id) AS total_sessions
  FROM Sessions
  GROUP BY event_id
)
SELECT e.event_id,
       e.event_name,
       sc.total_sessions
FROM session_counts sc
JOIN Events e ON e.event_id = sc.event_id
WHERE sc.total_sessions = (
  SELECT MAX(total_sessions) FROM session_counts
);

-- Exercise 13: Average Rating per City
-- Average rating of events in each city.
SELECT e.city,
       ROUND(AVG(f.rating),2) AS avg_rating,
       COUNT(f.feedback_id) AS feedback_count
FROM Events e
JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.city
ORDER BY avg_rating DESC;

-- Exercise 14: Most Registered Events
-- Top 3 events by registration count.
SELECT e.event_id,
       e.event_name,
       COUNT(r.registration_id) AS registration_count
FROM Events e
JOIN Registrations r ON r.event_id = e.event_id
GROUP BY e.event_id, e.event_name
ORDER BY registration_count DESC
LIMIT 3;

-- Exercise 15: Event Session Time Conflict
-- Identify overlapping sessions within the same event.
SELECT s1.event_id,
       e.event_name,
       s1.session_id AS session_a,
       s1.session_title AS session_a_title,
       s2.session_id AS session_b,
       s2.session_title AS session_b_title,
       s1.start_datetime AS a_start,
       s1.end_datetime AS a_end,
       s2.start_datetime AS b_start,
       s2.end_datetime AS b_end
FROM Sessions s1
JOIN Sessions s2 ON s1.event_id = s2.event_id
  AND s1.session_id < s2.session_id
  AND s1.start_datetime < s2.end_datetime
  AND s2.start_datetime < s1.end_datetime
JOIN Events e ON e.event_id = s1.event_id
ORDER BY s1.event_id, s1.start_datetime;

-- Exercise 16: Unregistered Active Users
-- Users created in last 30 days with no registrations.
SELECT u.user_id,
       u.first_name,
       u.last_name,
       u.email,
       u.created_at
FROM Users u
LEFT JOIN Registrations r ON r.user_id = u.user_id
WHERE u.created_at >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
  AND r.registration_id IS NULL
ORDER BY u.created_at DESC;

-- Exercise 17: Multi-Session Speakers
-- Speakers handling more than one session.
SELECT u.user_id,
       CONCAT(u.first_name,' ',u.last_name) AS speaker_name,
       COUNT(s.session_id) AS session_count
FROM Users u
JOIN Sessions s ON s.speaker_id = u.user_id
GROUP BY u.user_id, speaker_name
HAVING session_count > 1
ORDER BY session_count DESC;

-- Exercise 18: Resource Availability Check
-- Events without resources.
SELECT e.event_id,
       e.event_name,
       e.city,
       e.start_date,
       e.end_date
FROM Events e
LEFT JOIN Resources r ON r.event_id = e.event_id
WHERE r.resource_id IS NULL
ORDER BY e.start_date;

-- Exercise 19: Completed Events with Feedback Summary
-- Show registrations and average ratings for completed events.
SELECT e.event_id,
       e.event_name,
       COUNT(DISTINCT r.registration_id) AS registration_count,
       ROUND(AVG(f.rating),2) AS avg_rating
FROM Events e
LEFT JOIN Registrations r ON r.event_id = e.event_id
LEFT JOIN Feedback f ON f.event_id = e.event_id
WHERE e.status = 'completed'
GROUP BY e.event_id, e.event_name
ORDER BY registration_count DESC;

-- Exercise 20: User Engagement Index
-- Events attended and feedback submitted per user.
SELECT u.user_id,
       CONCAT(u.first_name,' ',u.last_name) AS user_name,
       COUNT(DISTINCT r.event_id) AS events_attended,
       COUNT(f.feedback_id) AS feedback_count
FROM Users u
LEFT JOIN Registrations r ON r.user_id = u.user_id
LEFT JOIN Feedback f ON f.user_id = u.user_id
GROUP BY u.user_id, user_name
ORDER BY events_attended DESC, feedback_count DESC;

-- Exercise 21: Top Feedback Providers
-- Top 5 users with most feedback entries.
SELECT u.user_id,
       CONCAT(u.first_name,' ',u.last_name) AS user_name,
       COUNT(f.feedback_id) AS feedback_count
FROM Users u
JOIN Feedback f ON f.user_id = u.user_id
GROUP BY u.user_id, user_name
ORDER BY feedback_count DESC
LIMIT 5;

-- Exercise 22: Duplicate Registrations Check
-- Find duplicate registrations for same user and event.
SELECT user_id,
       event_id,
       COUNT(registration_id) AS duplicate_count,
       GROUP_CONCAT(registration_id ORDER BY registration_id) AS registration_ids
FROM Registrations
GROUP BY user_id, event_id
HAVING duplicate_count > 1;

-- Exercise 23: Registration Trends
-- Month-wise registration count for past 12 months.
SELECT DATE_FORMAT(registration_date, '%Y-%m') AS month,
       COUNT(registration_id) AS registrations
FROM Registrations
WHERE registration_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY month
ORDER BY month;

-- Exercise 24: Average Session Duration per Event
-- Calculate average session duration in minutes.
SELECT e.event_id,
       e.event_name,
       ROUND(AVG(TIMESTAMPDIFF(MINUTE, s.start_datetime, s.end_datetime)), 1) AS avg_session_minutes
FROM Events e
JOIN Sessions s ON s.event_id = e.event_id
GROUP BY e.event_id, e.event_name
ORDER BY avg_session_minutes DESC;

-- Exercise 25: Events Without Sessions
-- List all events having no sessions.
SELECT e.event_id,
       e.event_name,
       e.city,
       e.start_date,
       e.end_date
FROM Events e
LEFT JOIN Sessions s ON s.event_id = e.event_id
WHERE s.session_id IS NULL
ORDER BY e.start_date;
