-- Advanced Query Solutions for Event Management Portal
-- Each section includes a basic query, optimized version, explanation, and expected output format.

USE `event_management_portal`;

-- 1. TOP RATED EVENTS USING WINDOW FUNCTIONS
-- Basic solution using GROUP BY.
SELECT e.event_id,
       e.event_name,
       COUNT(f.feedback_id) AS feedback_count,
       ROUND(AVG(f.rating),2) AS avg_rating
FROM Events e
JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.event_id, e.event_name
HAVING feedback_count >= 10
ORDER BY avg_rating DESC
LIMIT 10;

-- Optimized solution using derived table pre-aggregation and proper indexes.
WITH event_feedback AS (
  SELECT event_id,
         COUNT(*) AS feedback_count,
         AVG(rating) AS avg_rating
  FROM Feedback
  GROUP BY event_id
  HAVING feedback_count >= 10
)
SELECT e.event_id,
       e.event_name,
       ef.feedback_count,
       ROUND(ef.avg_rating,2) AS avg_rating
FROM event_feedback ef
JOIN Events e ON e.event_id = ef.event_id
ORDER BY ef.avg_rating DESC, ef.feedback_count DESC
LIMIT 10;

-- Explanation:
-- The CTE computes aggregates once and reduces repeated work. This is more efficient when Event rows are large.
-- Expected output format: event_id, event_name, feedback_count, avg_rating.

-- 2. TOP CITIES BY ENGAGED USERS USING RANK()
-- Basic solution using GROUP BY.
SELECT e.city,
       COUNT(DISTINCT r.user_id) AS engaged_users,
       COUNT(r.registration_id) AS registrations
FROM Registrations r
JOIN Events e ON e.event_id = r.event_id
GROUP BY e.city
ORDER BY engaged_users DESC
LIMIT 5;

-- Optimized solution using window function ranking.
WITH city_engagement AS (
  SELECT e.city,
         COUNT(DISTINCT r.user_id) AS engaged_users,
         COUNT(r.registration_id) AS registrations
  FROM Registrations r
  JOIN Events e ON e.event_id = r.event_id
  GROUP BY e.city
)
SELECT city,
       engaged_users,
       registrations
FROM (
  SELECT ce.*,
         DENSE_RANK() OVER (ORDER BY engaged_users DESC, registrations DESC) AS city_rank
  FROM city_engagement ce
) ranked
WHERE city_rank <= 5
ORDER BY engaged_users DESC, registrations DESC;

-- Explanation:
-- DENSE_RANK allows ties to be handled cleanly. The CTE isolates grouped metrics before the window function.
-- Expected output format: city, engaged_users, registrations.

-- 3. USER ENGAGEMENT INDEX WITH WINDOW FUNCTIONS
-- Basic solution using aggregates.
SELECT u.user_id,
       CONCAT(u.first_name,' ',u.last_name) AS user_name,
       COUNT(DISTINCT r.event_id) AS events_attended,
       COUNT(f.feedback_id) AS feedback_count,
       COUNT(DISTINCT r.event_id) + COUNT(f.feedback_id) AS engagement_index
FROM Users u
LEFT JOIN Registrations r ON r.user_id = u.user_id
LEFT JOIN Feedback f ON f.user_id = u.user_id
GROUP BY u.user_id, user_name
ORDER BY engagement_index DESC
LIMIT 10;

-- Optimized solution using a derived table and COALESCE.
WITH user_activity AS (
  SELECT u.user_id,
         CONCAT(u.first_name,' ',u.last_name) AS user_name,
         COALESCE(reg.events_attended, 0) AS events_attended,
         COALESCE(fb.feedback_count, 0) AS feedback_count
  FROM Users u
  LEFT JOIN (
    SELECT user_id,
           COUNT(DISTINCT event_id) AS events_attended
    FROM Registrations
    GROUP BY user_id
  ) reg ON reg.user_id = u.user_id
  LEFT JOIN (
    SELECT user_id,
           COUNT(*) AS feedback_count
    FROM Feedback
    GROUP BY user_id
  ) fb ON fb.user_id = u.user_id
)
SELECT user_id,
       user_name,
       events_attended,
       feedback_count,
       (events_attended + feedback_count) AS engagement_index
FROM user_activity
ORDER BY engagement_index DESC, events_attended DESC;

-- Explanation:
-- Splitting calculations into separate subqueries avoids multiplicative row expansion before aggregation.
-- Expected output format: user_id, user_name, events_attended, feedback_count, engagement_index.

-- 4. EVENTS WITH NO RESOURCES
-- Basic solution using LEFT JOIN.
SELECT e.event_id,
       e.event_name,
       e.city,
       e.start_date,
       e.end_date
FROM Events e
LEFT JOIN Resources r ON r.event_id = e.event_id
WHERE r.resource_id IS NULL
ORDER BY e.start_date;

-- Optimized solution using NOT EXISTS.
SELECT e.event_id,
       e.event_name,
       e.city,
       e.start_date,
       e.end_date
FROM Events e
WHERE NOT EXISTS (
  SELECT 1 FROM Resources r WHERE r.event_id = e.event_id
)
ORDER BY e.start_date;

-- Explanation:
-- NOT EXISTS is often faster for anti-join patterns and avoids duplicate rows due to JOIN semantics.
-- Expected output format: event_id, event_name, city, start_date, end_date.

-- 5. OVERLAPPING SESSIONS DETECTION
-- Basic solution using self-join.
SELECT s1.event_id,
       e.event_name,
       s1.session_id AS session_a,
       s1.session_title AS session_a_title,
       s2.session_id AS session_b,
       s2.session_title AS session_b_title,
       s1.start_datetime AS a_start,
       s1.end_datetime AS a_end,
       s2.start_datetime AS b_start,
       s2.end_datetime AS b_end
FROM Sessions s1
JOIN Sessions s2 ON s1.event_id = s2.event_id
  AND s1.session_id < s2.session_id
  AND s1.start_datetime < s2.end_datetime
  AND s2.start_datetime < s1.end_datetime
JOIN Events e ON e.event_id = s1.event_id
ORDER BY s1.event_id, s1.start_datetime;

-- Optimized solution with an indexed approach.
SELECT s1.event_id,
       e.event_name,
       s1.session_id AS session_a,
       s1.session_title AS session_a_title,
       s2.session_id AS session_b,
       s2.session_title AS session_b_title,
       s1.start_datetime AS a_start,
       s1.end_datetime AS a_end,
       s2.start_datetime AS b_start,
       s2.end_datetime AS b_end
FROM Sessions s1
JOIN Sessions s2 USE INDEX (idx_sessions_start_datetime) ON s1.event_id = s2.event_id
  AND s1.session_id < s2.session_id
  AND s1.start_datetime < s2.end_datetime
  AND s2.start_datetime < s1.end_datetime
JOIN Events e ON e.event_id = s1.event_id
ORDER BY s1.event_id, s1.start_datetime;

-- Explanation:
-- Using indexes on start_datetime and event_id can speed up the self-join for overlapping intervals.
-- Expected output format: event_id, event_name, session_a, session_b, a_start, a_end, b_start, b_end.

-- 6. REGISTRATION TRENDS LAST 12 MONTHS
-- Basic solution using DATE_FORMAT for grouping by month.
SELECT DATE_FORMAT(registration_date, '%Y-%m') AS month,
       COUNT(*) AS registrations
FROM Registrations
WHERE registration_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY month
ORDER BY month;

-- Optimized solution using a derived table and index-friendly filter.
SELECT month,
       registrations
FROM (
  SELECT DATE_FORMAT(registration_date, '%Y-%m') AS month,
         COUNT(*) AS registrations
  FROM Registrations
  WHERE registration_date BETWEEN DATE_SUB(LAST_DAY(CURDATE()), INTERVAL 11 MONTH) AND CURDATE()
  GROUP BY month
) trends
ORDER BY month;

-- Explanation:
-- Using BETWEEN with date bounds helps the optimizer use the registration_date index and improves performance.
-- Expected output format: month, registrations.
