-- Report queries for the Event Management Portal.

USE `event_management_portal`;

-- Monthly Registration Report
SELECT DATE_FORMAT(r.registration_date, '%Y-%m') AS month,
       COUNT(r.registration_id) AS registrations,
       COUNT(DISTINCT r.user_id) AS distinct_users,
       COUNT(DISTINCT r.event_id) AS distinct_events
FROM Registrations r
WHERE r.registration_date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY month
ORDER BY month;

-- Monthly Feedback Report
SELECT DATE_FORMAT(f.submitted_at, '%Y-%m') AS month,
       COUNT(f.feedback_id) AS total_feedback,
       ROUND(AVG(f.rating),2) AS average_rating,
       SUM(CASE WHEN f.rating <= 2 THEN 1 ELSE 0 END) AS low_feedback_count
FROM Feedback f
WHERE f.submitted_at >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY month
ORDER BY month;

-- Top Organizers Report
SELECT u.user_id AS organizer_id,
       CONCAT(u.first_name,' ',u.last_name) AS organizer_name,
       COUNT(e.event_id) AS event_count,
       SUM(CASE WHEN e.status = 'completed' THEN 1 ELSE 0 END) AS completed_events,
       SUM(CASE WHEN e.status = 'upcoming' THEN 1 ELSE 0 END) AS upcoming_events,
       ROUND(AVG(f.rating),2) AS organizer_avg_rating
FROM Users u
LEFT JOIN Events e ON e.organizer_id = u.user_id
LEFT JOIN Feedback f ON f.event_id = e.event_id
WHERE u.user_type = 'organizer'
GROUP BY u.user_id, organizer_name
ORDER BY event_count DESC, organizer_avg_rating DESC
LIMIT 10;

-- Top Cities Report
SELECT e.city,
       COUNT(DISTINCT r.user_id) AS distinct_attendees,
       COUNT(r.registration_id) AS registrations,
       ROUND(AVG(f.rating),2) AS avg_feedback_rating
FROM Events e
LEFT JOIN Registrations r ON r.event_id = e.event_id
LEFT JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.city
ORDER BY registrations DESC, avg_feedback_rating DESC
LIMIT 10;

-- Resource Usage Report
SELECT e.event_id,
       e.event_name,
       SUM(CASE WHEN r.resource_type = 'pdf' THEN 1 ELSE 0 END) AS pdf_count,
       SUM(CASE WHEN r.resource_type = 'image' THEN 1 ELSE 0 END) AS image_count,
       SUM(CASE WHEN r.resource_type = 'link' THEN 1 ELSE 0 END) AS link_count,
       SUM(CASE WHEN r.resource_type = 'video' THEN 1 ELSE 0 END) AS video_count,
       SUM(CASE WHEN r.resource_type = 'slide' THEN 1 ELSE 0 END) AS slide_count,
       COUNT(r.resource_id) AS total_resources
FROM Events e
LEFT JOIN Resources r ON r.event_id = e.event_id
GROUP BY e.event_id, e.event_name
ORDER BY total_resources DESC;

-- Event Participation Report
SELECT e.event_id,
       e.event_name,
       e.city,
       e.status,
       COUNT(DISTINCT r.user_id) AS attendee_count,
       COUNT(f.feedback_id) AS feedback_count,
       ROUND(AVG(f.rating),2) AS avg_rating
FROM Events e
LEFT JOIN Registrations r ON r.event_id = e.event_id
LEFT JOIN Feedback f ON f.event_id = e.event_id
GROUP BY e.event_id, e.event_name, e.city, e.status
ORDER BY attendee_count DESC, avg_rating DESC;
