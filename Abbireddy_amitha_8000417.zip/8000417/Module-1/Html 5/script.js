// This script handles the interactive behavior for the portal.
// Use Chrome Inspect Element > Console tab to view log messages.
// Set breakpoints in the Sources tab to pause code execution while debugging.

const STORAGE_KEY = 'communityEventSelection';
const SESSION_KEY = 'sessionVisitInfo';

function logDebug(message) {
  console.log(message);
}

function init() {
  logDebug('Page loaded');

  // Restore saved event selection from localStorage.
  const savedSelection = localStorage.getItem(STORAGE_KEY);
  const eventTypeSelect = document.getElementById('eventType');

  if (savedSelection && eventTypeSelect) {
    eventTypeSelect.value = savedSelection;
    showEventFee(eventTypeSelect);
    logDebug('Restored event selection from localStorage: ' + savedSelection);
  }

  // Save temporary session info in sessionStorage.
  sessionStorage.setItem(SESSION_KEY, JSON.stringify({
    lastVisit: new Date().toLocaleString(),
    note: 'Temporary session information saved'
  }));
  logDebug('Saved temporary session data');

  // Add click event for clearing preferences.
  const clearBtn = document.getElementById('clearPrefsBtn');
  if (clearBtn) {
    clearBtn.addEventListener('click', clearPreferences);
  }

  // Add click event for geolocation.
  const geoBtn = document.getElementById('geoBtn');
  if (geoBtn) {
    geoBtn.addEventListener('click', findNearbyEvents);
  }

  // Add submit event for the form.
  const form = document.getElementById('registrationForm');
  if (form) {
    form.addEventListener('submit', handleFormSubmit);
  }

  // Add double-click support for gallery images.
  document.querySelectorAll('.gallery-img').forEach((img) => {
    img.addEventListener('dblclick', enlargeGalleryImage);
  });

  // Add live character count to textarea.
  const messageField = document.getElementById('message');
  if (messageField) {
    updateCharCount(messageField);
  }

  // Add beforeunload warning if the form has content.
  window.onbeforeunload = function () {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const eventDate = document.getElementById('eventDate').value;
    const phone = document.getElementById('phone').value;
    const message = document.getElementById('message').value;

    if (name || email || eventDate || phone || message) {
      logDebug('User attempted to leave with unsaved form data');
      return 'You have unsaved form data.';
    }
  };
}

function validatePhoneNumber(input) {
  const value = input.value.trim();
  const phonePattern = /^[0-9]{10}$/;

  if (!phonePattern.test(value)) {
    input.setCustomValidity('Phone number must be exactly 10 digits.');
    input.reportValidity();
    logDebug('Phone validation failed');
  } else {
    input.setCustomValidity('');
    logDebug('Phone validation passed');
  }
}

function showEventFee(selectElement) {
  const feeDisplay = document.getElementById('feeDisplay');
  const selectedValue = selectElement.value;

  let feeText = 'Select an event to see its fee.';

  if (selectedValue === 'Music Event') {
    feeText = 'Music Event = ₹100';
  } else if (selectedValue === 'Sports Event') {
    feeText = 'Sports Event = ₹150';
  } else if (selectedValue === 'Workshop') {
    feeText = 'Workshop = ₹200';
  }

  if (feeDisplay) {
    feeDisplay.textContent = feeText;
  }

  localStorage.setItem(STORAGE_KEY, selectedValue);
  logDebug('Dropdown changed to: ' + selectedValue);
}

function showConfirmationAlert() {
  alert('You are about to submit your registration.');
  logDebug('Submit button clicked');
}

function enlargeGalleryImage(event) {
  const image = event.target;

  document.querySelectorAll('.gallery-img.enlarged').forEach((galleryImage) => {
    if (galleryImage !== image) {
      galleryImage.classList.remove('enlarged');
    }
  });

  image.classList.toggle('enlarged');
  logDebug('Gallery image enlarged: ' + image.getAttribute('data-caption'));

  if (image.classList.contains('enlarged')) {
    setTimeout(() => {
      image.classList.remove('enlarged');
    }, 2000);
  }
}

function updateCharCount(textarea) {
  const count = textarea.value.length;
  const charCount = document.getElementById('charCount');

  if (charCount) {
    charCount.textContent = count + ' characters';
  }

  logDebug('Character count updated: ' + count);
}

function handleFormSubmit(event) {
  event.preventDefault();
  logDebug('Form submitted');

  const confirmationMessage = document.getElementById('confirmationMessage');
  const form = document.getElementById('registrationForm');

  if (confirmationMessage) {
    confirmationMessage.textContent = 'Registration submitted successfully!';
  }

  if (form) {
    form.reset();
  }

  document.getElementById('feeDisplay').textContent = 'Select an event to see its fee.';
  document.getElementById('charCount').textContent = '0 characters';

  // Save the current session data again after successful submit.
  sessionStorage.setItem(SESSION_KEY, JSON.stringify({
    lastVisit: new Date().toLocaleString(),
    status: 'Registration submitted successfully'
  }));

  logDebug('Form reset after submission');
}

function clearPreferences() {
  localStorage.clear();
  sessionStorage.clear();
  alert('Preferences cleared.');
  logDebug('Preferences cleared');
}

function findNearbyEvents() {
  logDebug('Geolocation requested');

  const geoOutput = document.getElementById('geoOutput');

  if (!navigator.geolocation) {
    geoOutput.textContent = 'Geolocation is not supported by this browser.';
    return;
  }

  navigator.geolocation.getCurrentPosition(
    function (position) {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;

      geoOutput.innerHTML = `
        <strong>Nearby Events</strong><br>
        Latitude: ${lat}<br>
        Longitude: ${lon}
      `;

      logDebug('Geolocation success: ' + lat + ', ' + lon);
    },
    function (error) {
      let message = 'Unable to find location.';

      if (error.code === error.PERMISSION_DENIED) {
        message = 'Permission denied. Please allow geolocation access.';
      } else if (error.code === error.POSITION_UNAVAILABLE) {
        message = 'Position unavailable. Please try again.';
      } else if (error.code === error.TIMEOUT) {
        message = 'Timeout while requesting location.';
      }

      geoOutput.textContent = message;
      logDebug('Geolocation error: ' + message);
    },
    { enableHighAccuracy: true, timeout: 5000 }
  );
}

function videoReady() {
  const videoStatus = document.getElementById('videoStatus');
  if (videoStatus) {
    videoStatus.textContent = 'Video ready to play';
  }
  logDebug('Video ready to play');
}

// Initialize when DOM is ready.
document.addEventListener('DOMContentLoaded', init);
